/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ies.torredelrey.facturas;

import ies.torredelrey.vista.Menu;

/**
 *
 * @author usuario
 */
public class Facturas {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.setVisible(true);
    }
}
